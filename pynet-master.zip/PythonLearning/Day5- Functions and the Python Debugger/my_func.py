ip_addr2 = '192.168.1.1'
def print_ip(ip_addr, username='admin', password='cisco123'):
    print("My IP address is: {}".format(ip_addr))
    print(username)
    print(password)
    return