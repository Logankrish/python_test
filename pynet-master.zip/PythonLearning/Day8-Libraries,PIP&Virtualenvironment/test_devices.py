rtr1 = {
    'ip': '1.1.1.1',
    'username': 'admin',
    'password': 'test123',
    'device_type': 'cisco_ios',
}