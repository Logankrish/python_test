import ipdb  # noqa


class NetworkDevice:
    def __init__(self):
        pass


ipdb.set_trace()
rtr1 = NetworkDevice()
rtr2 = NetworkDevice()
