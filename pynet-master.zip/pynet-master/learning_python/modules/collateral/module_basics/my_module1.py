ip_addr = "8.8.8.8"
print(f"DNS Server IP: {ip_addr}")
