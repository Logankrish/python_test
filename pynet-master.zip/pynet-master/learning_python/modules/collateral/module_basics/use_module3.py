import my_module3

my_module3.dns_ip()
my_module3.dns_ip(dns="4.4.2.2")
