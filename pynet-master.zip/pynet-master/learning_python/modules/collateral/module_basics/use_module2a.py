import my_module2

my_module2.dns_ip()
my_module2.dns_ip(dns="1.1.1.1")
