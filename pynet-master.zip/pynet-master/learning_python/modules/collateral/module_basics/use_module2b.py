from my_module2 import dns_ip

dns_ip()
dns_ip(dns="1.1.1.1")
