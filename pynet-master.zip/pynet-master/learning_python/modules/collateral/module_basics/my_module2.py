def dns_ip(dns="8.8.8.8"):
    print(f"DNS Server: {dns}")
