rtr1 = {
    "host": "rtr1.domain.com",
    "username": "cisco",
    "password": "cisco123",
    "device_type": "cisco_ios",
}
