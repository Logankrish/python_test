from show_version.model import obtain_model
from show_version.os_version import obtain_os_version
from show_version.uptime import obtain_uptime
