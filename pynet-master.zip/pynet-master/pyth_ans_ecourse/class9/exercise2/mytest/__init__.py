from mytest.world import func1
from mytest.simple import func2
from mytest.whatever import func3
