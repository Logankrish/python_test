from mytest.world import func1, MyClass
from mytest.simple import func2
from mytest.whatever import func3

__all__ = ('func1', 'func2', 'func3', 'MyClass')
