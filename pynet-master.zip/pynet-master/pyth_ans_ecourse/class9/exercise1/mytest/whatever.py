'''
Python class on writing reusable code
'''
def func3():
    '''Simple test function'''
    print "Whatever"

if __name__ == "__main__":
    print "Main program - whatever"
