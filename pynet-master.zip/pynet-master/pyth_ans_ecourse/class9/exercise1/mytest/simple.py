'''
Python class on writing reusable code
'''
def func2():
    '''Simple test function'''
    print "Simple"

if __name__ == "__main__":
    print "Main program - simple"
