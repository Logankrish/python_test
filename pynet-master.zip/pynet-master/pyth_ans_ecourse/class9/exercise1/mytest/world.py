'''
Python class on writing reusable code
'''
def func1():
    '''Simple test function'''
    print "Hello world"

if __name__ == "__main__":
    print "Main program - world"
