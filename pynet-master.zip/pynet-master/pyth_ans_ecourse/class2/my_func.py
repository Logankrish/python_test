def my_func():
    print "hello"
