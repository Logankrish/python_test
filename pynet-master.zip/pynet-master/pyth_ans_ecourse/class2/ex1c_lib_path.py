#!/usr/bin/env python

import my_func

my_func.my_func()
