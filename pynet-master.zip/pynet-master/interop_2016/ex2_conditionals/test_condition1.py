a = raw_input("Enter value: ")
a = int(a)

if a == 15:
    print "Hello"
elif a >= 7:
    print "Something"
else:
    print "Nada"
