# Testing truth

if 1:
    print "1 is True"

if not "":
    print "Null string is False"

if not None:
    print "None is False"

if ['whatever']:
    print "List with one element is True"
