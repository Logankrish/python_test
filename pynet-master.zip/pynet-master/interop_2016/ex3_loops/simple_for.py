
my_list = [1, 2, 9, 'whatever', True, []]

for element in my_list:
    print element

