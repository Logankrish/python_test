
i = 0
while True:
    print i, "Hello"
    if i >= 10:
        break
    i += 1
